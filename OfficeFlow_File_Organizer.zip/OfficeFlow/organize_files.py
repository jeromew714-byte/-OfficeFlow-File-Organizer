import os
import shutil

print(">>> ORGANIZE_FILES.PY IS RUNNING <<<")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SOURCE_FOLDER = os.path.join(BASE_DIR, "messy_files")
TARGET_BASE = os.path.join(BASE_DIR, "Organized")

FILE_TYPES = {
    ".jpg": "Images",
    ".jpeg": "Images",
    ".png": "Images",
    ".gif": "Images",
    ".pdf": "PDFs",
    ".doc": "Documents",
    ".docx": "Documents",
    ".txt": "Documents",
    ".dwg": "CAD",
}

print("\nPreview Mode is OFF.")
choice = input("Proceed and MOVE files? (y/n): ").lower()
if choice != "y":
    print("Cancelled.")
    exit()

files = os.listdir(SOURCE_FOLDER)

for file in files:
    file_path = os.path.join(SOURCE_FOLDER, file)

    if os.path.isfile(file_path):
        ext = os.path.splitext(file)[1].lower()
        folder = FILE_TYPES.get(ext, "Other")

        target_folder = os.path.join(TARGET_BASE, folder)
        os.makedirs(target_folder, exist_ok=True)

        destination = os.path.join(target_folder, file)
        shutil.move(file_path, destination)

        print(f"MOVED: {file} → {folder}")

print("\nDone.")
